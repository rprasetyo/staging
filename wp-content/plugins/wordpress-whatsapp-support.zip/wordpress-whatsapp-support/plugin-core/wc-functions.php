<?php

// Preventing to direct access
defined('ABSPATH') OR die('Direct access not acceptable!');

