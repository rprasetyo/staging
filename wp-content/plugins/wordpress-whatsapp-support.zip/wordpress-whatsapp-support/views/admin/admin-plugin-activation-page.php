<div class="wrap">
    
    <div class="wecreativez-activation-form">
        <?php do_action( 'wws_plugin_activation_form' ); ?>
    </div>

</div>